﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.DTOs
{
    public class InvestmentPlanDto
    {
        public int PlanId { get; set; }
        public int ClientId { get; set; }
        public string InvestmentObjective { get; set; }
        public RiskAppetite? RiskAppetite { get; set; }
    }
    public class CreateInvestmentPlanDto
    {
        [Required]
        public int ClientId { get; set; }
        public string InvestmentObjective { get; set; }
        public RiskAppetite? RiskAppetite { get; set; }
    }
    public class UpdateInvestmentPlanDto
    {
        [Required]
        public int PlanId { get; set; }
        public string InvestmentObjective { get; set; }
        public RiskAppetite? RiskAppetite { get; set; }
    }
}
