﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WealthManagement.DataAccess.DTOs
{
    public class PortfolioDto
    {
        public int PortfolioId { get; set; }
        public int ClientId { get; set; }
        public decimal TotalValue { get; set; }
        public string AllocationSummary { get; set; }
        public DateTime? LastUpdated { get; set; }
    }
    public class CreatePortfolioDto
    {
        [Required]
        public int ClientId { get; set; }
        public decimal TotalValue { get; set; }
        public string AllocationSummary { get; set; }
        public DateTime? LastUpdated { get; set; }
    }
    public class UpdatePortfolioDto
    {
        [Required]
        public int PortfolioId { get; set; }
        public decimal TotalValue { get; set; }
        public string AllocationSummary { get; set; }
        public DateTime? LastUpdated { get; set; }
    }
}
