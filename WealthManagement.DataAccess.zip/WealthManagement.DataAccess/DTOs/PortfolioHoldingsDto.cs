﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WealthManagement.DataAccess.DTOs
{
    public class PortfolioHoldingDto
    {
        public int HoldingId { get; set; }
        public int PortfolioId { get; set; }
        public string AssetType { get; set; }
        public decimal AssetValue { get; set; }
    }
    public class CreatePortfolioHoldingDto
    {
        [Required]
        public int PortfolioId { get; set; }
        [StringLength(50)]
        public string AssetType { get; set; }
        public decimal AssetValue { get; set; }
    }
    public class UpdatePortfolioHoldingDto
    {
        [Required]
        public int HoldingId { get; set; }
        [StringLength(50)]
        public string AssetType { get; set; }
        public decimal AssetValue { get; set; }
    }
}
