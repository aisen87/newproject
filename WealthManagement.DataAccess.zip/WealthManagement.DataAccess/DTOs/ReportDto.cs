﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WealthManagement.DataAccess.DTOs
{
    public class ReportDto
    {
        public int ReportId { get; set; }
        public int ClientId { get; set; }
        public DateTime ReportDate { get; set; }
        public string PerformanceSummary { get; set; }
    }
    public class CreateReportDto
    {
        [Required]
        public int ClientId { get; set; }
    }
}
