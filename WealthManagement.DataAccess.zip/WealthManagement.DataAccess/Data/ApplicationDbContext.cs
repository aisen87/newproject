﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()//initilazitation
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Client> Clients { get; set; }//usig it we can turn into entity
        public DbSet<InvestmentPlan> InvestmentPlans { get; set; }
        public DbSet<Portfolio> Portfolios { get; set; }
        public DbSet<PortfolioHoldings> PortfolioHoldings { get; set; }
        public DbSet<Report> Reports { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Get the connection string from the configuration
                var connectionString = "Server=LTIN523300\\SQLEXPRESS;Database=WMS_DB;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True;";
                optionsBuilder.UseSqlServer(connectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<InvestmentPlan>()
                .HasOne(p => p.Client)
                .WithMany() 
                .HasForeignKey(p => p.ClientId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Portfolio>()
                .HasOne(p => p.Client)
                .WithMany() 
                .HasForeignKey(p => p.ClientId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<PortfolioHoldings>()
                .HasOne(h => h.Portfolio)
                .WithMany() 
                .HasForeignKey(h => h.PortfolioId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Report>()
                .HasOne(r => r.Client)
                .WithMany() 
                .HasForeignKey(r => r.ClientId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<AuditLog>()
                .HasOne(a => a.Client)
                .WithMany()
                .HasForeignKey(a => a.ClientId)
                .OnDelete(DeleteBehavior.Restrict) 
                .IsRequired();
        }
    }
}