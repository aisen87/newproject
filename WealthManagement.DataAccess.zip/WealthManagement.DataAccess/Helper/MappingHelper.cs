﻿using WealthManagement.DataAccess.DTOs;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Helpers
{
    public static class MappingHelper
    {
        // Client mappings
        public static ClientDto ToDto(this Client client) =>
            new ClientDto
            {
                ClientId = client.ClientId,
                Name = client.Name,
                Email = client.Email,
                Phone = client.Phone,
                Address = client.Address,
                DateOfBirth = client.DateOfBirth
            };

        public static Client ToEntity(this CreateClientDto dto) =>
            new Client
            {
                Name = dto.Name,
                Email = dto.Email,
                Phone = dto.Phone,
                Address = dto.Address,
                DateOfBirth = dto.DateOfBirth
            };

        public static void UpdateEntity(this Client client, UpdateClientDto dto)
        {
            if (dto.Name != null) client.Name = dto.Name;
            if (dto.Email != null) client.Email = dto.Email;
            if (dto.Phone != null) client.Phone = dto.Phone;
            if (dto.Address != null) client.Address = dto.Address;
            client.DateOfBirth = dto.DateOfBirth; // Only update if value is provided
        }

        // InvestmentPlan mappings
        public static InvestmentPlanDto ToDto(this InvestmentPlan plan) =>
            new InvestmentPlanDto
            {
                PlanId = plan.PlanId,
                ClientId = plan.ClientId,
                InvestmentObjective = plan.InvestmentObjective,
                RiskAppetite = plan.RiskAppetite
            };

        public static InvestmentPlan ToEntity(this CreateInvestmentPlanDto dto) =>
            new InvestmentPlan
            {
                ClientId = dto.ClientId,
                InvestmentObjective = dto.InvestmentObjective,
                RiskAppetite = dto.RiskAppetite
            };

        public static void UpdateEntity(this InvestmentPlan plan, UpdateInvestmentPlanDto dto)
        {
            if (dto.InvestmentObjective != null) plan.InvestmentObjective = dto.InvestmentObjective;
            plan.RiskAppetite = dto.RiskAppetite;
        }

        // Portfolio mappings
        public static PortfolioDto ToDto(this Portfolio portfolio) =>
            new PortfolioDto
            {
                PortfolioId = portfolio.PortfolioId,
                ClientId = portfolio.ClientId,
                TotalValue = portfolio.TotalValue,
                AllocationSummary = portfolio.AllocationSummary,
                LastUpdated = portfolio.LastUpdated
            };

        public static Portfolio ToEntity(this CreatePortfolioDto dto) =>
            new Portfolio
            {
                ClientId = dto.ClientId,
                TotalValue = dto.TotalValue,
                AllocationSummary = dto.AllocationSummary,
                LastUpdated = dto.LastUpdated
            };

        public static void UpdateEntity(this Portfolio portfolio, UpdatePortfolioDto dto)
        {
            portfolio.TotalValue = dto.TotalValue;
            if (dto.AllocationSummary != null) portfolio.AllocationSummary = dto.AllocationSummary;
            portfolio.LastUpdated = dto.LastUpdated;
        }

        // PortfolioHoldings mappings
        public static PortfolioHoldingDto ToDto(this PortfolioHoldings holding) =>
            new PortfolioHoldingDto
            {
                HoldingId = holding.HoldingId,
                PortfolioId = holding.PortfolioId,
                AssetType = holding.AssetType,
                AssetValue = holding.AssetValue
            };

        public static PortfolioHoldings ToEntity(this CreatePortfolioHoldingDto dto) =>
            new PortfolioHoldings
            {
                PortfolioId = dto.PortfolioId,
                AssetType = dto.AssetType,
                AssetValue = dto.AssetValue
            };

        public static void UpdateEntity(this PortfolioHoldings holding, UpdatePortfolioHoldingDto dto)
        {
            if (dto.AssetType != null) holding.AssetType = dto.AssetType;
            holding.AssetValue = dto.AssetValue;
        }

        // Report mappings
        public static ReportDto ToDto(this Report report) =>
            new ReportDto
            {
                ReportId = report.ReportId,
                ClientId = report.ClientId,
                ReportDate = report.ReportDate,
                PerformanceSummary = report.PerformanceSummary
            };

        public static Report ToEntity(this CreateReportDto dto) =>
            new Report
            {
                ClientId = dto.ClientId,
                ReportDate = DateTime.Now // Set report date on creation
                // PerformanceSummary will likely be generated in the service/controller
            };

    }
}