﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WealthManagement.DataAccess.Models
{
    public class AuditLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LogId { get; set; }

        [Required]
        [ForeignKey("Client")]
        public int ClientId { get; set; }

        public DateTime EventTimestamp { get; set; } = DateTime.Now;

        [StringLength(255)]
        public string EventDescription { get; set; }

        public ComplianceStatus? ComplianceStatus { get; set; }

        // Navigation property to the Client
        public Client Client { get; set; }
    }

    public enum ComplianceStatus
    {
        Pass,
        Fail
    }
}