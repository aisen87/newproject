﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WealthManagement.DataAccess.Models
{
    public class InvestmentPlan
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlanId { get; set; }

        [Required]
        [ForeignKey("Client")]
        public int ClientId { get; set; }

        public string InvestmentObjective { get; set; }

        public RiskAppetite? RiskAppetite { get; set; }

        // Navigation property to the Client
        public Client Client { get; set; }
    }

    public enum RiskAppetite
    {
        Low,
        Medium,
        High
    }
}