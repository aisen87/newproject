﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WealthManagement.DataAccess.Models
{
    public class Portfolio
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PortfolioId { get; set; }

        [Required]
        [ForeignKey("Client")]
        public int ClientId { get; set; }

        [Column(TypeName = "decimal(15, 2)")]
        public decimal TotalValue { get; set; }

        public string AllocationSummary { get; set; } // Could be a JSON string or other format

        [DataType(DataType.Date)]
        public DateTime? LastUpdated { get; set; }

        // Navigation property to the Client
        public Client Client { get; set; }
    }
}