﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WealthManagement.DataAccess.Models
{
    public class PortfolioHoldings
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int HoldingId { get; set; }

        [Required]
        [ForeignKey("Portfolio")]
        public int PortfolioId { get; set; }

        [StringLength(50)]
        public string AssetType { get; set; }

        [Column(TypeName = "decimal(15, 2)")]
        public decimal AssetValue { get; set; }

        // Navigation property to the Portfolio
        public Portfolio Portfolio { get; set; }
    }
}