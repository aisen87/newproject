﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WealthManagement.DataAccess.Models
{
    public class Report
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ReportId { get; set; }

        [Required]
        [ForeignKey("Client")]
        public int ClientId { get; set; }

        [DataType(DataType.Date)]
        public DateTime ReportDate { get; set; }

        public string PerformanceSummary { get; set; }

        // Navigation property to the Client
        public Client Client { get; set; }
    }
}