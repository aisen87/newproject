﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Data;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public class AuditLogRepository : IAuditLogRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public AuditLogRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<AuditLog> GetByIdAsync(int id)
        {
            return await _dbContext.AuditLogs.FindAsync(id);
        }

        public async Task<IEnumerable<AuditLog>> GetAllAsync()
        {
            return await _dbContext.AuditLogs.ToListAsync();
        }

        public async Task<IEnumerable<AuditLog>> GetByClientIdAsync(int clientId)
        {
            return await _dbContext.AuditLogs.Where(a => a.ClientId == clientId).ToListAsync();
        }

        public async Task AddAsync(AuditLog log)
        {
            _dbContext.AuditLogs.Add(log);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(AuditLog log)
        {
            _dbContext.Entry(log).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var log = await _dbContext.AuditLogs.FindAsync(id);
            if (log != null)
            {
                _dbContext.AuditLogs.Remove(log);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}