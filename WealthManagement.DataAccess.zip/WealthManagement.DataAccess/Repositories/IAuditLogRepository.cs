﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public interface IAuditLogRepository
    {
        Task<AuditLog> GetByIdAsync(int id);
        Task<IEnumerable<AuditLog>> GetAllAsync();
        Task<IEnumerable<AuditLog>> GetByClientIdAsync(int clientId);
        Task AddAsync(AuditLog log);
        Task UpdateAsync(AuditLog log);
        Task DeleteAsync(int id);
    }
}