﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public interface IInvestmentPlanRepository
    {
        Task<InvestmentPlan> GetByIdAsync(int id);
        Task<IEnumerable<InvestmentPlan>> GetAllAsync();
        Task<IEnumerable<InvestmentPlan>> GetByClientIdAsync(int clientId);
        Task AddAsync(InvestmentPlan plan);
        Task UpdateAsync(InvestmentPlan plan);
        Task DeleteAsync(int id);
    }
}