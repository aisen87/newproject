﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public interface IPortfolioHoldingsRepository
    {
        Task<PortfolioHoldings> GetByIdAsync(int id);
        Task<IEnumerable<PortfolioHoldings>> GetAllAsync();
        Task<IEnumerable<PortfolioHoldings>> GetByPortfolioIdAsync(int portfolioId);
        Task AddAsync(PortfolioHoldings holding);
        Task UpdateAsync(PortfolioHoldings holding);
        Task DeleteAsync(int id);
    }
}