﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public interface IPortfolioRepository
    {
        Task<Portfolio> GetByIdAsync(int id);
        Task<IEnumerable<Portfolio>> GetAllAsync();
        Task<Portfolio> GetByClientIdAsync(int clientId);
        Task AddAsync(Portfolio portfolio);
        Task UpdateAsync(Portfolio portfolio);
        Task DeleteAsync(int id);
    }
}