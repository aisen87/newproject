﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public interface IReportRepository
    {
        Task<Report> GetByIdAsync(int id);
        Task<IEnumerable<Report>> GetAllAsync();
        Task<IEnumerable<Report>> GetByClientIdAsync(int clientId);
        Task AddAsync(Report report);
        Task UpdateAsync(Report report);
        Task DeleteAsync(int id);
    }
}