﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Data;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public class InvestmentPlanRepository : IInvestmentPlanRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public InvestmentPlanRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<InvestmentPlan> GetByIdAsync(int id)
        {
            return await _dbContext.InvestmentPlans.FindAsync(id);
        }

        public async Task<IEnumerable<InvestmentPlan>> GetAllAsync()
        {
            return await _dbContext.InvestmentPlans.Include(p => p.Client).ToListAsync();
        }

        public async Task<IEnumerable<InvestmentPlan>> GetByClientIdAsync(int clientId)
        {
            return await _dbContext.InvestmentPlans.Where(p => p.ClientId == clientId).ToListAsync();
        }

        public async Task AddAsync(InvestmentPlan plan)
        {
            _dbContext.InvestmentPlans.Add(plan);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(InvestmentPlan plan)
        {
            _dbContext.Entry(plan).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var plan = await _dbContext.InvestmentPlans.FindAsync(id);
            if (plan != null)
            {
                _dbContext.InvestmentPlans.Remove(plan);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}