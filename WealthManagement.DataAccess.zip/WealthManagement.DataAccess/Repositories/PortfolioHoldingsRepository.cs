﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Data;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public class PortfolioHoldingsRepository : IPortfolioHoldingsRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public PortfolioHoldingsRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<PortfolioHoldings> GetByIdAsync(int id)
        {
            return await _dbContext.PortfolioHoldings.FindAsync(id);
        }

        public async Task<IEnumerable<PortfolioHoldings>> GetAllAsync()
        {
            return await _dbContext.PortfolioHoldings.ToListAsync();
        }

        public async Task<IEnumerable<PortfolioHoldings>> GetByPortfolioIdAsync(int portfolioId)
        {
            return await _dbContext.PortfolioHoldings.Where(h => h.PortfolioId == portfolioId).ToListAsync();
        }

        public async Task AddAsync(PortfolioHoldings holding)
        {
            _dbContext.PortfolioHoldings.Add(holding);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(PortfolioHoldings holding)
        {
            _dbContext.Entry(holding).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var holding = await _dbContext.PortfolioHoldings.FindAsync(id);
            if (holding != null)
            {
                _dbContext.PortfolioHoldings.Remove(holding);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}