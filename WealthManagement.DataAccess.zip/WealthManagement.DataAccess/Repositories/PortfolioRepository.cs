﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Data;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public class PortfolioRepository : IPortfolioRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public PortfolioRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Portfolio> GetByIdAsync(int id)
        {
            return await _dbContext.Portfolios.FindAsync(id);
        }

        public async Task<IEnumerable<Portfolio>> GetAllAsync()
        {
            return await _dbContext.Portfolios.ToListAsync();
        }

        public async Task<Portfolio> GetByClientIdAsync(int clientId)
        {
            return await _dbContext.Portfolios.FirstOrDefaultAsync(p => p.ClientId == clientId);
        }

        public async Task AddAsync(Portfolio portfolio)
        {
            _dbContext.Portfolios.Add(portfolio);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(Portfolio portfolio)
        {
            _dbContext.Entry(portfolio).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var portfolio = await _dbContext.Portfolios.FindAsync(id);
            if (portfolio != null)
            {
                _dbContext.Portfolios.Remove(portfolio);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}