﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WealthManagement.DataAccess.Data;
using WealthManagement.DataAccess.Models;

namespace WealthManagement.DataAccess.Repositories
{
    public class ReportRepository : IReportRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public ReportRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Report> GetByIdAsync(int id)
        {
            return await _dbContext.Reports.FindAsync(id);
        }

        public async Task<IEnumerable<Report>> GetAllAsync()
        {
            return await _dbContext.Reports.ToListAsync();
        }

        public async Task<IEnumerable<Report>> GetByClientIdAsync(int clientId)
        {
            return await _dbContext.Reports.Where(r => r.ClientId == clientId).ToListAsync();
        }

        public async Task AddAsync(Report report)
        {
            _dbContext.Reports.Add(report);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(Report report)
        {
            _dbContext.Entry(report).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var report = await _dbContext.Reports.FindAsync(id);
            if (report != null)
            {
                _dbContext.Reports.Remove(report);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}